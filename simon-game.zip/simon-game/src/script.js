var beep1=$("#beep1")[0];
var beep2=$("#beep2")[0];
var beep3=$("#beep3")[0];
var beep4=$("#beep4")[0];
var choice=[];
var line=[];
var turn=0;
var last=0;

function help(){
  setTimeout(function(){ 
    alert("new turn"); 
  }, 3000);
}
function check(){
  if($(".zero").hasClass("hide")==true){
  }
  $(".zero").removeClass("hide");
}
function checkError(original,arr){
  
  
  var game="winning";
  for(var j=0;j<arr.length;j++){
    if(arr[j]!=original[j]){
      game="lost";
    }
   }
  if(game=="winning"){
    $("#test").css("background-color","green");
    $("#cover").addClass("hide");
    $(".layer").fadeTo(1500,0.4, function(){
      $(".layer").css("background-color", "white");
      $(".layer").fadeTo(50,1);
    });
    if(turn==20){
      $(".win").removeClass("hide");
      turn=0;
      $("#round").text(turn);
      line=[];
      copy=[];
      choice=[];
      $("#start").prop("disabled", false);
    }else{
      $("#start").click();
    }
  }else{
    var reset=$(".zero").hasClass("hide");
    if($('input[type=checkbox]').prop('checked')==true||reset==true){
      $("#test").css("background-color","red");
      $(".layer").fadeTo(1500,0.4, function(){
        $(".layer").css("background-color", "white");
        $(".layer").fadeTo(50,1);
      });
      turn=0;
      line=[];
      copy=[];
      choice=[];
      check();
      $("#round").text(turn);
      $("#start").click();
    }else if($('input[type=checkbox]').prop('checked')==false){
      $("#test").css("background-color","red");
      $(".layer").fadeTo(1500,0.4, function(){
        $(".layer").css("background-color", "white");
        $(".layer").fadeTo(50,1);
      });
      turn=turn-1;
      last=original.pop();
      line=original;
      $("#start").click();
      
   }
  }
}


function usePromise(len){
  var promise = new Promise(function(resolve, reject) {
        var counting=0;
        $("#end").on("click", function(){
          for(var i=0; i<len; i++){
            $(".zero").click();
          }
        });
        $(".field").on("click",function(){
        counting++;
        if(counting==len){
            choice.push($(this).attr("id"));
            resolve(choice);
        }else if(counting<len){
            choice.push($(this).attr("id"));     
        }
        });
    });
    promise.then(function(result){
          checkError(line,result);
          $("#cover").removeClass("hide");
      }).catch(function(error) {
          console.log('Error occurred!', error);
      });
  }


function rand(){
  return 1+Math.floor(Math.random()*4);
}
var counting=[1];



$(document).ready(function(){
  $(".1").on("click", function(){
    beep1.play();
  });
  $(".2").on("click", function(){
    beep2.play();
  });
  $(".3").on("click", function(){
    beep3.play();
  });
  $(".4").on("click", function(){
    beep4.play();
  });
  
  $("#round").text(turn);
  function ready(){
    counting.forEach(function(){
      var newest=rand();
      line.push(newest);
    });
  }
  
  $("#end").on("click", function(){
    $(".zero").addClass("hide");
  });
  
  $("#start").on("click",function(){
    $("#start").prop("disabled", true);
    $("#cover").removeClass("hide");
    turn++;
    $("#round").text(turn);
    var copy=[];
    ready();
    if(last!=0){
      line.pop();
      line.push(last);
      last=0;
    }
    for(var i=0;i<line.length;i++){
      copy.push(line[i]);
    }
      var now=setInterval(function(){
        $("#end").on("click", function(){
          clearInterval(now);
          
        });
        $("#"+copy[0]).fadeTo(500,0.2,'linear', function(){
          if($(this).attr("id")==1){
            beep1.play();
          }else if($(this).attr("id")==2){
            beep2.play();
          }else if($(this).attr("id")==3){
            beep3.play();
          }else if($(this).attr("id")==4){
            beep4.play();
          }
          $(this).fadeTo(500,1);
        });
        copy.shift();
        if(copy.length==0){
          $("#cover").addClass("hide");
          clearInterval(now);
        }
      },1000);
      usePromise(line.length);
      choice=[];
    }); 
      
    });